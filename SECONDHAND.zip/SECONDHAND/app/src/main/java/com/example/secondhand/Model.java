package com.example.secondhand;


public class Model {


    String mProductName;
    String mProductDetail;
    int mProductPhoto;

    public Model(String mproductName, String mproductDetail, int mproductPhoto) {
        this.mProductName = mproductName;
        this.mProductDetail = mproductDetail;
        this.mProductPhoto = mproductPhoto;
    }




    public String getmProductName() {
        return mProductName;
    }

    public String getmProductDetail() {
        return mProductDetail;
    }

    public int getmProductPhoto() {
        return mProductPhoto;
    }
}
