package com.example.secondhand;


import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

import com.example.secondhand.Db0rder.OrderContract;

public class CartAdapter extends CursorAdapter {


    public CartAdapter(Context context, Cursor cursor) {
        super(context, cursor, 0);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.cartlist, parent, false);
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {

        // getting the views

        TextView productName, yesWrap, yesBag, price, quantity;


        productName = view.findViewById(R.id.productNameinOrderSummary);
        price = view.findViewById(R.id.priceinOrderSummary);
        yesWrap = view.findViewById(R.id.giftwrap);
        yesBag = view.findViewById(R.id.shoppingbag);
        quantity = view.findViewById(R.id.quantityinOrderSummary);

        // getting the values by first getting the position of their columns

        int name = cursor.getColumnIndex(OrderContract.OrderEntry.COLUMN_NAME);
        int priceofitem = cursor.getColumnIndex(OrderContract.OrderEntry.COLUMN_PRICE);
        int quantityofitem = cursor.getColumnIndex(OrderContract.OrderEntry.COLUMN_QUANTITY);
        int haswrap = cursor.getColumnIndex(OrderContract.OrderEntry.COLUMN_HASWRAP);
        int hasbag = cursor.getColumnIndex(OrderContract.OrderEntry.COLUMN_HASBAG);


        String nameofproduct = cursor.getString(name);
        String pricesofproduct = cursor.getString(priceofitem);
        String quantitysofproduct = cursor.getString(quantityofitem);
        String yeswrap = cursor.getString(haswrap);
        String yesbag = cursor.getString(hasbag);



        productName.setText(nameofproduct);
        price.setText(pricesofproduct);
        quantity.setText(quantitysofproduct);
        yesWrap.setText(yeswrap);
        yesBag.setText(yesbag);


    }
}

