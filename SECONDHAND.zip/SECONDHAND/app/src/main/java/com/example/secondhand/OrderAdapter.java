package com.example.secondhand;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.ViewHolder> {

    List<Model> modelList;
    Context context;

    public OrderAdapter(Context context, List<Model> modelList) {
        this.context = context;
        this.modelList = modelList;
    }

    @Override
    public ViewHolder onCreateViewHolder( ViewGroup parent, int i) {

        View view = LayoutInflater.from(context).inflate(R.layout.listitem, parent, false);
        return new ViewHolder(view);

    }

    @Override
    public void onBindViewHolder( ViewHolder holder, int position) {

        // here we will find the position and start setting the output on our views

        String nameofProduct = modelList.get(position).getmProductName();
        String descriptionofProduct = modelList.get(position).getmProductDetail();
        int images = modelList.get(position).getmProductPhoto();

        holder.mProductName.setText(nameofProduct);
        holder.mProductDescription.setText(descriptionofProduct);
        holder.imageView.setImageResource(images);

    }

    @Override
    public int getItemCount() {
        return modelList.size();
    }

    //in order to make our views responsive we can implement on click listener on our recyclerview

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        // here we will find the views on which we will inflate our data

        TextView mProductName, mProductDescription;
        ImageView imageView;

        public ViewHolder(View itemView) {
            super(itemView);

            mProductName = itemView.findViewById(R.id.productName);
            mProductDescription = itemView.findViewById(R.id.description);
            imageView = itemView.findViewById(R.id.productImage);
            itemView.setOnClickListener(this);


        }

        @Override
        public void onClick(View v) {

            // lets get the position of the view in list and then work on it

            int position = getAdapterPosition();
            //for(int i=0; i<drawableResourceArray.length; i++) //for(int i=0; i<6; i++)
            // {
             //   Intent intent = new Intent( context, ProductActivity.class );
              //  intent.putExtra( "position", position );
               // context.startActivity( intent );
            //}
            if (position == 0) {
                Intent intent = new Intent(context, ProductActivity.class);
                intent.putExtra( "position",position );
                context.startActivity(intent);
            }
            else if (position == 1) {
                Intent intent2 = new Intent(context, ProductActivity.class);
                context.startActivity(intent2);
            }
            else if (position == 2) {
                Intent intent2 = new Intent(context, ProductActivity.class);
                context.startActivity(intent2);
            }
            else if (position == 3) {
                Intent intent2 = new Intent(context, ProductActivity.class);
                context.startActivity(intent2);
            }
            else if (position == 4) {
                Intent intent2 = new Intent(context, ProductActivity.class);
                context.startActivity(intent2);
            }

        }
    }
}


