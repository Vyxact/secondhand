package com.example.secondhand;

import android.app.LoaderManager;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.example.secondhand.Db0rder.OrderContract;

public class ProductActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {

    // first of all we will get the views that are  present in the layout of info

    ImageView imageView;
    ImageButton plusquantity, minusquantity;
    TextView quantitynumber, ProductName, ProductPrice;
    CheckBox addShoppingBag,addGiftWrap;
    Button addtoCart;
    int quantity;
    public Uri mCurrentCartUri;
    boolean hasAllRequiredValues = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        imageView = findViewById(R.id.imageViewInfo);
        plusquantity = findViewById(R.id.addquantity);
        minusquantity  = findViewById(R.id.subquantity);
        quantitynumber = findViewById(R.id.quantity);
        ProductName = findViewById(R.id.productNameinInfo);
        ProductPrice = findViewById(R.id.productPrice);
        addShoppingBag = findViewById(R.id.addshopbag);
        addtoCart = findViewById(R.id.addtocart);
        addGiftWrap = findViewById(R.id.addgiftwrap);

        // setting the name of item


        ProductName.setText("Blue Female Jean");

        addtoCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProductActivity.this, SummaryActivity.class);
                startActivity(intent);
                // once this button is clicked we want to save our values in the database and send those values
                // right away to summary activity where we display the order info

                SaveCart();
            }
        });

        plusquantity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // item price
                int basePrice = 6;
                quantity++;
                displayQuantity();
                int itemPrice = basePrice * quantity;
                String setnewPrice = String.valueOf(itemPrice);
                ProductPrice.setText(setnewPrice);


                // checkBoxes functionality

                int ifCheckBox = CalculatePrice(addGiftWrap, addShoppingBag);
                ProductPrice.setText(ifCheckBox + " rmb");

            }
        });

        minusquantity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int basePrice = 6;
                // because we dont want the quantity go less than 0
                if (quantity == 0) {
                    Toast.makeText(ProductActivity.this, "Cant decrease quantity < 0", Toast.LENGTH_SHORT).show();
                } else {
                    quantity--;
                    displayQuantity();
                    int coffePrice = basePrice * quantity;
                    String setnewPrice = String.valueOf(coffePrice);
                    ProductPrice.setText(setnewPrice);


                    // checkBoxes functionality

                    int ifCheckBox = CalculatePrice(addGiftWrap, addShoppingBag);
                    ProductPrice.setText( ifCheckBox+" rmb" );
                }
            }
        });



    }

    private boolean SaveCart() {

        // getting the values from our views
        String name = ProductName.getText().toString();
        String price = ProductPrice.getText().toString();
        String quantity = quantitynumber.getText().toString();

        ContentValues values = new ContentValues();
        values.put(OrderContract.OrderEntry.COLUMN_NAME, name);
        values.put(OrderContract.OrderEntry.COLUMN_PRICE, price);
        values.put(OrderContract.OrderEntry.COLUMN_QUANTITY, quantity);

        if (addGiftWrap.isChecked()) {
            values.put(OrderContract.OrderEntry.COLUMN_HASWRAP, "Want gift wrap?: YES");
        } else {
            values.put(OrderContract.OrderEntry.COLUMN_HASWRAP, "Want gift wrap?: NO");

        }

        if (addShoppingBag.isChecked()) {
            values.put(OrderContract.OrderEntry.COLUMN_HASBAG, "Want shopping gift?: YES");
        } else {
            values.put(OrderContract.OrderEntry.COLUMN_HASBAG, "Want shopping gift?: NO");

        }

        if (mCurrentCartUri == null) {
            Uri newUri = getContentResolver().insert(OrderContract.OrderEntry.CONTENT_URI, values);
            if (newUri==null) {
                Toast.makeText(this, "Failed to add to Cart", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Success  adding to Cart", Toast.LENGTH_SHORT).show();

            }
        }

        hasAllRequiredValues = true;
        return hasAllRequiredValues;

    }

    private int CalculatePrice(CheckBox addGiftWrap, CheckBox addShoppingBag) {

        int basePrice = 8;

        if (addGiftWrap.isChecked()) {
            // add the gift wrap cost $1
            basePrice = basePrice + 1;
        }

        if (addShoppingBag.isChecked()) {
            // shopping bag cost is $1
            basePrice = basePrice + 1;
        }

        return basePrice * quantity;
    }

    private void displayQuantity() {
        quantitynumber.setText(String.valueOf(quantity));
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        String[] projection = {OrderContract.OrderEntry._ID,
                OrderContract.OrderEntry.COLUMN_NAME,
                OrderContract.OrderEntry.COLUMN_PRICE,
                OrderContract.OrderEntry.COLUMN_QUANTITY,
                OrderContract.OrderEntry.COLUMN_HASWRAP,
                OrderContract.OrderEntry.COLUMN_HASBAG
        };

        return new CursorLoader(this, mCurrentCartUri,
                projection,
                null,
                null,
                null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {

        if (cursor == null || cursor.getCount() < 1) {
            return;
        }

        if (cursor.moveToFirst()) {

            int name = cursor.getColumnIndex(OrderContract.OrderEntry.COLUMN_NAME);
            int price = cursor.getColumnIndex(OrderContract.OrderEntry.COLUMN_PRICE);
            int quantity = cursor.getColumnIndex(OrderContract.OrderEntry.COLUMN_QUANTITY);
            int hasWrap = cursor.getColumnIndex(OrderContract.OrderEntry.COLUMN_HASBAG);
            int hasBag = cursor.getColumnIndex(OrderContract.OrderEntry.COLUMN_HASWRAP);


            String nameofitem = cursor.getString(name);
            String priceofitem = cursor.getString(price);
            String quantityofitem = cursor.getString(quantity);
            String yeshasGiftwrap = cursor.getString(hasWrap);
            String yeshasShoppingbag = cursor.getString(hasBag);

            ProductName.setText(nameofitem);
            ProductPrice.setText(priceofitem);
            quantitynumber.setText(quantityofitem);
            addGiftWrap.setText(yeshasGiftwrap);
            addShoppingBag.setText(yeshasShoppingbag);
        }


    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {


        ProductName.setText("");
        ProductPrice.setText("");
        quantitynumber.setText("");
        addGiftWrap.setText("");
        addShoppingBag.setText("");

    }
}

