package com.example.secondhand;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<Model> modelList=new ArrayList<>();
    RecyclerView recyclerView;
    OrderAdapter mAdapter;
    String[]  productListNames = {"Jean","Jean","Jean","Jean","Jean"};
    String[]  productListDescription = {"Beautiful Blue Female Jean","Beautiful Blue Female Jean","Beautiful Blue Female Jean","Beautiful Blue Female Jean","Beautiful Blue Female Jean"};

    int[] drawableResourceArray = new int[]{
            R.drawable.femalejeans,R.drawable.femalejeans,R.drawable.femalejeans,
            R.drawable.femalejeans,R.drawable.femalejeans
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //:::::: list products
        for(int i=0; i<productListNames.length; i++){
            modelList.add(new Model(productListNames[i], productListDescription[i], drawableResourceArray[i]));
        }
        // recyclerview
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(null));
        // adapter
         mAdapter = new OrderAdapter(this, modelList);
        recyclerView.setAdapter( mAdapter);

    }
}

